import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Category } from './model/Category';
import { Product } from './model/Product';
import { User } from './model/User';
import { Injectable } from '@angular/core';

const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};
@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  categoryStatus: boolean
  adminStatus: boolean
  currentUser: User
  productStatus: boolean
  public products: Product[]
  public categorys: Category[]
  
  constructor(public http: HttpClient) {
    this.categoryStatus = false
    this.categorys = []
    this.productStatus = false
    this.products = []
  }
  addCategory(category: Category) {
    return this.http.post('http://172.18.218.134:8444/grocery/category/save', category, httpOptions)
  }
  getCategory()
  {
    return this.http.get('http://172.18.218.134:8444/grocery/category/all', httpOptions)
  }
  deleteComment(cid: number) {
    return this.http.delete('http://172.18.218.134:8444/grocery/category/delete/' + cid, httpOptions)
  }

  addProduct(product: Product) {
    return this.http.post('http://172.18.218.134:8444/grocery/product/save', product, httpOptions)
  }

  getProduct() {
    return this.http.get('http://172.18.218.134:8444/grocery/product/all', httpOptions)
  }
  
 
}
