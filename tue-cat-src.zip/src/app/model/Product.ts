export class Product {
    pid: number
    pname: string
    pqty: number
    unit: string
    price: number
    category: string
    cfk: number
    constructor() {
        this.pid = 0
        this.pname = ''
        this.pqty = 0
        this.unit = ''
        this.price = 0
        this.category = ''
        this.cfk = 0

    }
}
